NEW ROUND GPS LOGGER

Built from the four photographed route-list pages supplied in chat.
62 clearly visible destinations were transcribed in photo/page order.

Use on iPhone via HTTPS (for example GitHub Pages). Safari requires a secure site for GPS.
Tap SAVE GPS HERE while physically at the destination. Allow Location access when asked.
Use Backup GPS / Export CSV regularly.

This is a separate app and does not alter the Moelfre Daily Round Planner.
